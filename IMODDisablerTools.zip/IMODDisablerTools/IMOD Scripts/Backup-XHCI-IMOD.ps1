﻿param(
    [switch]$verbose
)

# Made by Quaked
# TikTok: _Quaked_
# Discord: https://discord.gg/8NqDSMzYun
#
# XHCI IMOD Backup Script, reads and saves the current IMOD values for later use.
# Utility/Program Credit: Valleyofdoom/Amitxv - XHCI-IMOD-Interval.ps1
# IMOD Information: https://github.com/valleyofdoom/PC-Tuning#1139-xhci-interrupt-moderation-imod-permalink

# common offsets across XHCI vendors that will work with most XHCI controllers
$globalHCSPARAMSOffset = 0x4
$globalRTSOFF = 0x18

$userDefinedData = @{}

# Backup location
$backupPath = "C:\IMOD Disabler Tools\IMOD Backup\XHCI-IMOD-Backup.json"

# Specify the path to Rw.exe
$rwePath = "C:\Program Files (x86)\RW-Everything\Rw.exe"

function Dec-ToHex($decimal) {
    $hexValue = $decimal.ToString("X2")
    return "0x$($hexValue)"
}

function Get-ValueFromAddress($address) {
    # convert the hex value to string for RWE
    $address = Dec-ToHex -decimal ([uint64]$address)

    $stdout = & $rwePath /Min /NoLogo /Stdout /Command="R32 $($address)" | Out-String
    $splitString = $stdout -split " "
    return [uint64]$splitString[-1]
}

function Get-DeviceAddresses() {
    $data = @{}
    $resources = Get-WmiObject -Class Win32_PNPAllocatedResource -ComputerName LocalHost -Namespace root\CIMV2

    foreach ($resource in $resources) {
        $deviceId = $resource.Dependent.Split("=")[1].Replace('"', '').Replace("\\", "\")
        $physicalAddress = $resource.Antecedent.Split("=")[1].Replace('"', '')

        if (-not $data.ContainsKey($deviceId) -and $deviceId -and $physicalAddress) {
            $data[$deviceId] = [uint64]$physicalAddress
        }
    }

    return $data
}

function Is-Admin() {
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function main() {
    if (-not (Is-Admin)) {
        Write-Host "error: administrator privileges required"
        return 1
    }

    if (-not (Test-Path $rwePath -PathType Leaf)) {
        Write-Host "error: $($rwePath) not exists, edit the script to change the path to Rw.exe"
        Write-Host "http://rweverything.com/download"
        return 1
    }

    # Create backup folder if it does not exist
    $backupDirectory = Split-Path $backupPath

    if (-not (Test-Path $backupDirectory)) {
        New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
    }

    # Do not overwrite an existing backup
    if (Test-Path $backupPath) {
        Write-Host "❌ An IMOD backup already exists." -ForegroundColor Red
        Write-Host Path: "$backupPath" -ForegroundColor Red
        Write-Host "Delete the existing backup if you want to create a new one." -ForegroundColor Red
        return 1
    }

    # CLI will not work if Rw is already open
    Stop-Process -Name "Rw" -ErrorAction SilentlyContinue

    # get physical address of each device present in the system
    $deviceMap = Get-DeviceAddresses

    # store backup data
    $backupData = @()

    foreach ($xhciController in Get-WmiObject Win32_USBController) {
        $isDisabled = $xhciController.ConfigManagerErrorCode -eq 22

        if ($isDisabled) {
            continue
        }

        $deviceId = $xhciController.DeviceID

        # check if there is data defined for the current controller by the user
        $userDefinedController = @{}

        foreach ($hwid in $userDefinedData.Keys) {
            if ($deviceId -match $hwid) {
                $userDefinedController = $userDefinedData[$hwid]
            }
        }

        # check if the user has specified not to apply the IMOD for the current controller
        if ($userDefinedController.ContainsKey("ENABLED") -and (-not $userDefinedController["ENABLED"])) {
            continue
        }

        Write-Host "$($xhciController.Caption) - $($deviceId)"

        # skip if entry is null
        if (-not $deviceMap.Contains($deviceId)) {
            Write-Host "error: could not obtain base address`n"
            continue
        }

        $hcsparamsOffset = $globalHCSPARAMSOffset
        $rtsoff = $globalRTSOFF

        # process the user defined data
        if ($userDefinedController.ContainsKey("HCSPARAPS_OFFSET")) {
            $hcsparamsOffset = $userDefinedController["HCSPARAPS_OFFSET"]
        }

        if ($userDefinedController.ContainsKey("RTSOFF")) {
            $rtsoff = $userDefinedController["RTSOFF"]
        }

        $capabilityAddress = $deviceMap[$deviceId]
        $HCSPARAMSValue = Get-ValueFromAddress -address ($capabilityAddress + $hcsparamsOffset)
        $HCSPARAMSBitmask = [Convert]::ToString($HCSPARAMSValue, 2)
        $maxIntrs = [Convert]::ToInt32($HCSPARAMSBitmask.Substring($HCSPARAMSBitmask.Length - 16, 8), 2)
        $RTSOFFValue = Get-ValueFromAddress -address ($capabilityAddress + $rtsoff)
        $runtimeAddress = $capabilityAddress + $RTSOFFValue

        if ($verbose) {
            $formattedCapabilityAddress = Dec-ToHex -decimal $capabilityAddress
            $formattedRTSOFFValue = Dec-ToHex -decimal $RTSOFFValue

            Write-Host "capability_address  = $($formattedCapabilityAddress)"
            Write-Host "HCSPARAMS_value     = capability_address + hcsparams_offset = $($formattedCapabilityAddress) + $(Dec-ToHex -decimal $hcsparamsOffset) = $(Dec-ToHex -decimal $HCSPARAMSValue)"
            Write-Host "HCSPARAMS_bitmask   = $($HCSPARAMSBitmask)"
            Write-Host "max_intrs           = $($maxIntrs)"
            Write-Host "RTSOFF_value        = capability_address + rtsoff = $($formattedCapabilityAddress) + $($formattedRTSOFFValue) = $(Dec-ToHex -decimal $RTSOFFValue)"
            Write-Host "runtime_address     = capability_address + RTSOFF_value = $($formattedCapabilityAddress) + $($formattedRTSOFFValue) = $(Dec-ToHex -decimal $runtimeAddress)"
        }

        for ($i = 0; $i -lt $maxIntrs; $i++) {
            # calculate address and convert address to hex string
            $interrupterAddressDecimal = [uint64]($runtimeAddress + 0x24 + (0x20 * $i))
            $interrupterAddress = Dec-ToHex -decimal $interrupterAddressDecimal

            if ($verbose) {
                Write-Host "`ninterrupter_address = runtime_address + 0x24 + (0x20 * index) = $(Dec-ToHex -decimal $runtimeAddress) + 0x24 + (0x20 * $($i)) = $($interrupterAddress)"
            }

            # READ the current IMOD value
            $currentInterval = Get-ValueFromAddress -address $interrupterAddressDecimal

            if ($verbose) {
                Write-Host "Current IMOD value = $(Dec-ToHex -decimal $currentInterval)"
            }

            # Store the current value in the backup
            $backupData += [PSCustomObject]@{
                DeviceID = $deviceId
                Interrupter = $i
                Address = $interrupterAddressDecimal
                OriginalInterval = $currentInterval
            }
        }

        Write-Host # new line
    }

    # Save backup data to JSON
    $backupData | ConvertTo-Json -Depth 5 | Set-Content -Path $backupPath -Encoding UTF8

    Write-Host "✔  IMOD backup saved successfully."
    Write-Host "Path: $backupPath"
    return 0
}

$_exitCode = main
Write-Host # new line
exit $_exitCode
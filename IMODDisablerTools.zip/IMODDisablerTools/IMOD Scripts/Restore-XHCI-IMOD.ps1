﻿param(
    [switch]$verbose
)

# Made by Quaked
# TikTok: _Quaked_
# Discord: https://discord.gg/8NqDSMzYun
#
# XHCI IMOD Restore Script, reads and applies the backed up IMOD values.
# Utility/Program Credit: Valleyofdoom/Amitxv - XHCI-IMOD-Interval.ps1
# IMOD Information: https://github.com/valleyofdoom/PC-Tuning#1139-xhci-interrupt-moderation-imod-permalink

# Backup location
$backupPath = "C:\IMOD Disabler Tools\IMOD Backup\XHCI-IMOD-Backup.json"

# specify the path to Rw.exe
$rwePath = "C:\Program Files (x86)\RW-Everything\Rw.exe"

function Dec-ToHex($decimal) {
    $hexValue = $decimal.ToString("X2")
    return "0x$($hexValue)"
}

function Is-Admin() {
    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function main() {
    if (-not (Is-Admin)) {
        Write-Host "error: administrator privileges required"
        return 1
    }

    if (-not (Test-Path $rwePath -PathType Leaf)) {
        Write-Host "error: $($rwePath) not exists, edit the script to change the path to Rw.exe"
        Write-Host "http://rweverything.com/download"
        return 1
    }

    if (-not (Test-Path $backupPath -PathType Leaf)) {
        Write-Host "error: IMOD backup does not exist:"
        Write-Host "$backupPath"
        Write-Host "Run the backup script first."
        return 1
    }

    # CLI will not work if Rw is already open
    Stop-Process -Name "Rw" -ErrorAction SilentlyContinue

    # Load backup
    $backupData = Get-Content -Path $backupPath -Raw | ConvertFrom-Json

    if (-not $backupData) {
        Write-Host "error: IMOD backup is empty"
        return 1
    }

    foreach ($entry in $backupData) {
        $interrupterAddress = Dec-ToHex -decimal ([uint64]$entry.Address)
        $originalInterval = [uint64]$entry.OriginalInterval

        if ($verbose) {
            Write-Host "`nController = $($entry.DeviceID)"
            Write-Host "Interrupter = $($entry.Interrupter)"
            Write-Host "Address = $($interrupterAddress)"
            Write-Host "Restore DWORD = $(Dec-ToHex -decimal $originalInterval)"
        }

        & $rwePath /Min /NoLogo /Stdout /Command="W32 $($interrupterAddress) $($originalInterval)" | Write-Host
    }

    Write-Host
    Write-Host "✔  Original XHCI IMOD values restored successfully."
    return 0
}

$_exitCode = main
Write-Host
exit $_exitCode